# CutMate Android app (native project)

A native Android starter app for meal logging, reusable recipes, calorie/macronutrient totals, workout calorie estimates, and weight goals. Data is stored locally using Android SharedPreferences.

## Build an installable APK
1. Install Android Studio (current stable) on a computer.
2. Open this `CutMateAndroid` folder as a project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK path; transfer it to your phone and install it. You may need to allow installs from that source.

## Notes
- Package: `com.cutmate.app`
- Minimum Android: 7.0 (API 24)
- Initial targets: 2,400 kcal, 150 g protein, 72 kg current, 65 kg goal.
- Nutrition values are approximate per 100 g (whey uses a serving-like entry, oil uses grams); use weighed ingredients and product labels for best accuracy.
- Workout calorie estimates use MET approximations and are not direct measurements.
- This project source is provided; an APK is not included because this environment does not have the Android SDK/Gradle build toolchain needed to compile and sign it.
